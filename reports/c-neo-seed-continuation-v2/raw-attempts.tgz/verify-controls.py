import subprocess,pathlib,hashlib,json
p=pathlib.Path('/workspace/work/seed-alignment');node='/workspace/work/runtime/node_modules/.bin/node';engine=str(p/'engine');borg='/workspace/work/danger-retreat-integration'
for label,toolkit in [('parent','/workspace/work/birth-alignment-toolkit'),('new',str(p/'toolkit'))]:
 build=p/f'control-{label}-build';cmd=[node,toolkit+'/tools/zoo/build.mjs','--engine-dir',engine,'--borg-dir',borg,'--engine-pin','18ee52eaa550aef7a2d10c822f6669cab57c6e7d','--borg-pin','9c17cb0c582fe129008899491372787e91abdade','--alignment-probes','true','--exact-tick-cap','true','--out',str(build)]
 if label=='new':cmd+=['--c-seed-startup','true']
 with (p/f'control-{label}-build.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 for profile in ['default','c-point-buy-v1']:
  cmd=[node,toolkit+'/tools/zoo/run.mjs','--bundle',str(build/'bundle.mjs'),'--seed','303','--race','Human','--class','Warrior','--turns','2000','--out',str(p/f'control-{label}-{profile}')]
  if profile!='default':cmd+=['--birth-profile',profile]
  with (p/f'control-{label}-{profile}.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
checks=[]
for profile in ['default','c-point-buy-v1']:
 for file in ['commands.jsonl','messages.jsonl']:
  a=hashlib.sha256((p/f'control-parent-{profile}'/file).read_bytes()).hexdigest();b=hashlib.sha256((p/f'control-new-{profile}'/file).read_bytes()).hexdigest();checks.append({'profile':profile,'file':file,'parent':a,'new':b,'pass':a==b})
(p/'unchanged-controls.json').write_text(json.dumps(checks,indent=2)+'\n');assert all(c['pass'] for c in checks)
