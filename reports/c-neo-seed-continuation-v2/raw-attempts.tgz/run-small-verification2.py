import subprocess,json,pathlib
root=pathlib.Path('/workspace/work/seed-alignment')
cases=[(303+i,'Human',c) for i,c in enumerate(['Warrior','Mage','Druid','Priest','Necromancer','Paladin','Rogue','Ranger','Blackguard'])]+[(313,'Dwarf','Warrior'),(314,'High-Elf','Mage')]
for seed,race,cls in cases:
 for side in ['neo']:
  out=root/f'verified2-{side}-{seed}'
  cmd=(['python',str(root/'toolkit/tools/zoo/alignment/native-driver.py'),'run','--harness','/workspace/work/birth-alignment/native-harness','--build',str(root/'native-stream-probe-build'),'--out',str(out),'--seed',str(seed),'--race',race,'--cls',cls,'--cap','2000'] if side=='c' else ['/workspace/work/runtime/node_modules/.bin/node',str(root/'toolkit/tools/zoo/run.mjs'),'--bundle',str(root/'gcc-both-build/bundle.mjs'),'--seed',str(seed),'--race',race,'--class',cls,'--birth-profile','c-seeded-point-buy-v2','--turns','2000','--out',str(out)])
  with (root/f'verified2-{side}-{seed}.log').open('w') as f: subprocess.run(['flock','/tmp/angband-validation.lock',*cmd],stdout=f,stderr=subprocess.STDOUT,check=True)
  print(seed,race,cls,side,flush=True)
